# 關於本書 📚

示範如何用 GitHub Pages + GitHub Actions 免費建立自己的 GitBook。

本書網址：https://books.onejar99.com/demo-build-and-publish-gitbook
